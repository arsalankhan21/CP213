package cp213;

import java.util.Scanner;

/**
 * Wraps around an Order object to ask for MenuItems and quantities.
 *
 * @author Arsalan Khan 210862640 khan6264@mylaurier.ca
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2023-04-02
 */
public class Cashier {

    // Attributes
    private Menu menu = null;

    /**
     * Constructor.
     *
     * @param menu A Menu.
     */
    public Cashier(Menu menu) {
	this.menu = menu;
    }

    /**
     * Prints the menu.
     */
    private void printCommands() {
	System.out.println("\nMenu:");
	System.out.println(menu.toString());
	System.out.println("Press 0 when done.");
	System.out.println("Press any other key to see the menu again.\n");
    }

    /**
     * Asks for commands and quantities. Prints a receipt when all orders have been
     * placed.
     *
     * @return the completed Order.
     */
    public Order takeOrder() {
	System.out.println("Welcome to WLU Foodorama!");

	boolean done = false;
	Order order = new Order();

	while (!done) {
	    printCommands();
	    Scanner input = new Scanner(System.in);
	    int itemNumber = input.nextInt();

	    if (itemNumber == 0) {
		done = true;

	    } else {
		MenuItem item = menu.getItem(itemNumber);
		if (item != null) {
		    System.out.print("Enter Quantity: ");
		    int quantity = input.nextInt();
		    order.add(item, quantity);
		} else {
		    System.out.print("Invalid item number");
		}
	    }
	}

	System.out.println("Thank you for you order!\n");
	System.out.println(order.toString());
	return order;
    }
}