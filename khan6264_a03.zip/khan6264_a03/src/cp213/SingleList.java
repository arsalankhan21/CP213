package cp213;

/**
 * A single linked list structure of <code>Node T</code> objects. These data
 * objects must be Comparable - i.e. they must provide the compareTo method.
 * Only the <code>T</code> value contained in the priority queue is visible
 * through the standard priority queue methods. Extends the
 * <code>SingleLink</code> class.
 *
 * @author Arsalan Khan 210862640 khan6264@mylaurier.ca
 * @version 2023-03-09
 * @param <T> this SingleList data type.
 */
public class SingleList<T extends Comparable<T>> extends SingleLink<T> {

    /**
     * Searches for the first occurrence of key in this SingleList. Private helper
     * methods - used only by other ADT methods.
     *
     * @param key The value to look for.
     * @return A pointer to the node previous to the node containing key.
     */
    private SingleNode<T> linearSearch(final T key) {

	SingleNode<T> current = this.front;
	SingleNode<T> previous = null;

	while (current != null && current.getDatum() != key) {
	    previous = current;
	    current = current.getNext();
	}

	return previous;
    }

    /**
     * Appends data to the end of this SingleList.
     *
     * @param datum The value to append.
     */
    public void append(final T datum) {

	SingleNode<T> newNode = new SingleNode<>(datum, null); // creating a node call newnode and adding the data and
							       // the pointer

	if (this.front == null) { // If the this.list is empty
	    this.front = newNode; // Setting
	} else {
	    SingleNode<T> current = this.front;

	    while (current.getNext() != null) {
		current = current.getNext();
	    }
	    current.setNext(newNode);
	}

	return;
    }

    /**
     * Removes duplicates from this SingleList. The list contains one and only one
     * of each value formerly present in this SingleList. The first occurrence of
     * each value is preserved.
     */
    public void clean() {

	SingleNode<T> current = this.front; // Creating a node instance for current
	SingleNode<T> runner; // Creating a node instance for runner
	while (current != null) { // While current is not empty
	    runner = current; // Set runner to current
	    while (runner.getNext() != null) { // While runner does not point to null
		if (runner.getNext().getDatum() == current.getDatum()) { // If runners point value's data is equal to
									 // currents data
		    runner.setNext(runner.getNext().getNext()); //
		} else {
		    runner = runner.getNext();
		}
	    }
	    current = current.getNext();
	}

	return;
    }

    /**
     * Combines contents of two lists into a third. Values are alternated from the
     * origin lists into this SingleList. The origin lists are empty when finished.
     * NOTE: data must not be moved, only nodes.
     *
     * @param left  The first list to combine with this SingleList.
     * @param right The second list to combine with this SingleList.
     */
    public void combine(final SingleList<T> left, final SingleList<T> right) {

	if (left.front == null) { // If the left singlelist is empty
	    this.front = right.front; // Set the front of this to the right
	    right.front = null; // Right one is set to empty
	    return;
	}

	if (right.front == null) { // If the right single list is empty
	    this.front = left.front; // Set the front of this to left
	    left.front = null;
	    return;
	}

	SingleNode<T> leftCurrent = left.front;
	SingleNode<T> rightCurrent = right.front;
	SingleNode<T> current = null;

	while (leftCurrent != null && rightCurrent != null) {
	    if (current == null) {
		current = leftCurrent;
		this.front = current;
	    } else {
		current.setNext(leftCurrent);
		current = current.getNext();
	    }
	    leftCurrent = leftCurrent.getNext();
	    current.setNext(rightCurrent);
	    current = current.getNext();
	    rightCurrent = rightCurrent.getNext();

	}

	if (leftCurrent != null) {
	    current.setNext(leftCurrent);
	}
	if (rightCurrent != null) {
	    current.setNext(rightCurrent);
	}

	return;
    }

    /**
     * Determines if this SingleList contains key.
     *
     * @param key The key value to look for.
     * @return true if key is in this SingleList, false otherwise.
     */
    public boolean contains(final T key) {
	boolean isFound = false;
	SingleNode<T> current = this.front;

	while (current != null) {
	    if (current.getDatum().compareTo(key) == 0) {
		isFound = true;
	    }
	    current = current.getNext();

	}
	return isFound;
    }

    /**
     * Finds the number of times key appears in list.
     *
     * @param key The value to look for.
     * @return The number of times key appears in this SingleList.
     */
    public int count(final T key) {
	int count = 0;
	SingleNode<T> current = this.front;
	while (current != null) {
	    if (key.compareTo(current.getDatum()) == 0) {
		count++;
	    }
	    current = current.getNext();
	}

	return count;
    }

    /**
     * Finds and returns the value in list that matches key.
     *
     * @param key The value to search for.
     * @return The value that matches key, null otherwise.
     */
    public T find(final T key) {
	SingleNode<T> current = this.front;

	while (current != null) {
	    if (key.compareTo(current.getDatum()) == 0) {
		return current.getDatum();
	    }
	    current = current.getNext();
	}
	return null;
    }

    /**
     * Get the nth item in this SingleList.
     *
     * @param n The index of the item to return.
     * @return The nth item in this SingleList.
     * @throws ArrayIndexOutOfBoundsException if n is not a valid index.
     */
    public T get(final int n) throws ArrayIndexOutOfBoundsException {

	T data = null;
	SingleNode<T> current = this.front;
	int i = 0;

	for (i = 0; i < n && current != null; i++) {
	    current = current.getNext();
	}
	if (current == null) {
	} else {
	    data = current.getDatum();
	}

	return data;
    }

    /**
     * Determines whether two lists are identical.
     *
     * @param source The list to compare against this SingleList.
     * @return true if this SingleList contains the same values in the same order as
     *         source, false otherwise.
     */
    public boolean identical(final SingleList<T> source) {

	if (source == null) {
	    return false;
	}

	SingleNode<T> node1 = this.front;
	SingleNode<T> node2 = source.front;

	while (node1 != null && node2 != null) {
	    if (!(node1.getDatum().compareTo(node2.getDatum()) == 0)) {
		return false;
	    }
	    node1 = node1.getNext();
	    node2 = node2.getNext();
	}

	return (node1 == null & node2 == null);
    }

    /**
     * Finds the first location of a value by key in this SingleList.
     *
     * @param key The value to search for.
     * @return The index of key in this SingleList, -1 otherwise.
     */
    public int index(final T key) {
	int index = 0;
	SingleNode<T> current = this.front;

	while (current != null) {
	    if (current.getDatum().compareTo(key) != 0) {
		current = current.getNext();
		index++;
	    } else {
		break;
	    }
	}
	if (current == null) {
	    index = -1;
	}
	return index;
    }

    /**
     * Inserts value into this SingleList at index i. If i greater than the length
     * of this SingleList, append data to the end of this SingleList.
     *
     * @param i     The index to insert the new data at.
     * @param datum The new value to insert into this SingleList.
     */
    public void insert(int i, final T datum) {
	if (i < 0) {
	    i = this.length + 1;
	}
	if (i > this.length) {
	    this.append(datum);
	} else if (i == 0) {
	    this.prepend(datum);
	} else {
	    int count = 0;
	    SingleNode<T> current = this.front;
	    SingleNode<T> previous = null;
	    while (i > count && current != null) {
		previous = current;
		current = current.getNext();
		++count;
	    }
	    SingleNode<T> insertednode = new SingleNode<T>(datum, current);
	    previous.setNext(insertednode);
	    this.length++;
	}

	return;
    }

    /**
     * Creates an intersection of two other SingleLists into this SingleList. Copies
     * data to this SingleList. left and right SingleLists are unchanged. Values
     * from left are copied in order first, then values from right are copied in
     * order.
     *
     * @param left  The first SingleList to create an intersection from.
     * @param right The second SingleList to create an intersection from.
     */
    public void intersection(final SingleList<T> left, final SingleList<T> right) {

	SingleNode<T> current = left.front;

	while (current != null) {
	    T x = current.getDatum();
	    if (right.contains(x)) {
		this.append(x);
	    }
	    current = current.getNext();
	}

	return;
    }

    /**
     * Finds the maximum value in this SingleList.
     *
     * @return The maximum value.
     */
    public T max() {

	if (this.front == null) {
	    return null;
	}
	T max = this.front.getDatum();
	SingleNode<T> current = this.front.getNext();
	while (current != null) {
	    T currentDatum = current.getDatum();
	    if (currentDatum.compareTo(max) > 0) {
		max = currentDatum;
	    }
	    current = current.getNext();
	}

	return max;
    }

    /**
     * Finds the minimum value in this SingleList.
     *
     * @return The minimum value.
     */
    public T min() {

	if (this.front == null) {
	    return null;
	}
	T min = this.front.getDatum();
	SingleNode<T> current = this.front.getNext();
	while (current != null) {
	    T currentDatum = current.getDatum();
	    if (currentDatum.compareTo(min) < 0) {
		min = currentDatum;
	    }
	    current = current.getNext();
	}

	return min;
    }

    /**
     * Inserts value into the front of this SingleList.
     *
     * @param datum The value to insert into the front of this SingleList.
     */
    public void prepend(final T datum) {
	SingleNode<T> current = this.front;
	SingleNode<T> newNode = new SingleNode<T>(datum, current);
	this.front = newNode;
	this.front.setNext(current);
	this.length++;

	return;
    }

    /**
     * Finds, removes, and returns the value in this SingleList that matches key.
     *
     * @param key The value to search for.
     * @return The value matching key, null otherwise.
     */
    public T remove(final T key) {
	if (this.front == null) {
	    return null;
	}
	if (this.front.getDatum().compareTo(key) == 0) {
	    T removedDatum = this.front.getDatum();
	    this.front = this.front.getNext();
	    return removedDatum;
	}
	SingleNode<T> previous = this.front;
	SingleNode<T> current = previous.getNext();

	while (current != null) {
	    if (current.getDatum().compareTo(key) == 0) {
		T removedDatum = current.getDatum();
		previous.setNext(current.getNext());
		return removedDatum;
	    }
	    previous = current;
	    current = current.getNext();
	}
	return null;

    }

    /**
     * Removes the value at the front of this SingleList.
     *
     * @return The value at the front of this SingleList.
     */
    public T removeFront() {

	T datum = null;
	if (this.front != null) {
	    datum = this.front.getDatum();
	    this.front = this.front.getNext();
	}

	this.length--;

	return datum;
    }

    /**
     * Finds and removes all values in this SingleList that match key.
     *
     * @param key The value to search for.
     */
    public void removeMany(final T key) {

	SingleNode<T> temp = this.front, prev = null;

	while (temp != null && temp.getDatum() == key) {
	    this.front = temp.getNext();
	    temp = this.front;
	}
	while (temp != null) {
	    while (temp != null && temp.getDatum() != key) {
		prev = temp;
		temp = temp.getNext();
	    }
	    temp = prev.getNext();

	}

	return;
    }

    /**
     * Reverses the order of the values in this SingleList.
     */
    public void reverse() {

	SingleNode<T> current = this.front;
	SingleNode<T> previous = null;
	SingleNode<T> next = null;
	while (current != null) {
	    next = current.getNext();
	    previous = current;
	    current = next;
	}

	return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move value or call the high-level methods insert
     * or remove. this SingleList is empty when done. The first half of this
     * SingleList is moved to left, and the last half of this SingleList is moved to
     * right. If the resulting lengths are not the same, left should have one more
     * item than right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void split(final SingleList<T> left, final SingleList<T> right) {

	int count = 0;
	int mid = this.length / 2;
	while (this.front != null) {
	    if (count < mid) {
		left.moveFrontToRear(this);
		count++;
	    } else {
		right.moveFrontToRear(this);
		count++;
	    }
	}

	return;
    }

    /**
     * Splits the contents of this SingleList into the left and right SingleLists.
     * Moves nodes only - does not move value or call the high-level methods insert
     * or remove. this SingleList is empty when done. Nodes are moved alternately
     * from this SingleList to left and right. Order is preserved.
     *
     * @param left  The first SingleList to move nodes to.
     * @param right The second SingleList to move nodes to.
     */
    public void splitAlternate(final SingleList<T> left, final SingleList<T> right) {

	int count = 0;
	while (this.front != null) {
	    if (count % 2 == 0) {
		left.moveFrontToRear(this);
	    } else {
		right.moveFrontToRear(this);
	    }
	    count++;
	}

	return;
    }

    /**
     * Creates a union of two other SingleLists into this SingleList. Copies value
     * to this list. left and right SingleLists are unchanged. Values from left are
     * copied in order first, then values from right are copied in order.
     *
     * @param left  The first SingleList to create a union from.
     * @param right The second SingleList to create a union from.
     */
    public void union(final SingleList<T> left, final SingleList<T> right) {

	SingleNode<T> leftnode = left.front;
	SingleNode<T> rightnode = right.front;

	while (leftnode != null) {
	    T x = leftnode.getDatum();
	    this.append(x);
	    leftnode = leftnode.getNext();
	}
	while (rightnode != null) {
	    T x = rightnode.getDatum();
	    if (!(this.contains(x))) {
		this.append(x);
	    }
	    rightnode = rightnode.getNext();

	}

	return;
    }
}
