package cp213;

/**
 * @author Arsalan Khan 210862640
 * @version 2023-01-24
 */
public class Strings {
    // Constants
    public static final String VOWELS = "aeiouAEIOU";

    /**
     * Determines if string is a "palindrome": a word, verse, or sentence (such as
     * "Able was I ere I saw Elba") that reads the same backward or forward. Ignores
     * case, spaces, digits, and punctuation in the string parameter s.
     *
     * @param string a string
     * @return true if string is a palindrome, false otherwise
     */
    public static boolean isPalindrome(final String string) {
	int l = 0;
	int h = string.length() - 1;
	boolean ispalin = false;

	String str = string.toLowerCase();

	while (l <= h) {

	    char char1 = str.charAt(l);
	    char char2 = str.charAt(h);

	    if (!(char1 >= 'a' && char1 <= 'z'))
		l++;

	    else if (!(char2 >= 'a' && char2 <= 'z'))
		h--;

	    else if (char1 == char2) {
		l++;
		h--;
	    }

	    else
		return ispalin;
	}

	// Returns true if sentence is palindrome
	ispalin = true;
	return ispalin;
    }

    /**
     * Determines if name is a valid Java variable name. Variables names must start
     * with a letter or an underscore, but cannot be an underscore alone. The rest
     * of the variable name may consist of letters, numbers and underscores.
     *
     * @param name a string to test as a Java variable name
     * @return true if name is a valid Java variable name, false otherwise
     */
    public static boolean isValid(final String name) {
	char initialvalue = name.charAt(0);
	int i = 0;
	boolean valid = false;

	if ((Character.isAlphabetic(initialvalue)) || (initialvalue == '_')) {
	    valid = true;
	}
	return valid;
    }

    /**
     * Converts a word to Pig Latin. The conversion is:
     * <ul>
     * <li>if a word begins with a vowel, add "way" to the end of the word.</li>
     * <li>if the word begins with consonants, move the leading consonants to the
     * end of the word and add "ay" to the end of that. "y" is treated as a
     * consonant if it is the first character in the word, and as a vowel for
     * anywhere else in the word.</li>
     * </ul>
     * Preserve the case of the word - i.e. if the first character of word is
     * upper-case, then the new first character should also be upper case.
     *
     * @param word The string to convert to Pig Latin
     * @return the Pig Latin version of word
     */
    public static String pigLatin(String word) {

	// Initialize variables
	int i = 0;
	char firstword;
	char vowelcomp;
	char firstCase;
	boolean isvowel = false;
	final String way = "way";
	final String ay = "ay";
	String firstconsonant;
	String secondconsonant;

	// Set first letter as first word
	firstword = word.charAt(i);
	// Loop through the vowels and ensure that first word != one of the vowels
	for (int j = 0; j < VOWELS.length(); j++) {
	    vowelcomp = VOWELS.charAt(j);
	    if (firstword == vowelcomp) {
		isvowel = true;
	    } else {
		j++;
	    }
	}

	if (isvowel) {
	    word = word + way;
	} else {
	    // Find the first consonant and create a char to determine case value
	    firstconsonant = word.substring(0, 1);
	    firstCase = firstconsonant.charAt(0);
	    // If case value is uppercase, take the second consonant out
	    // Make the word start for the third, and concat second, word, first then ay
	    if (Character.isUpperCase(firstCase)) {
		secondconsonant = word.substring(1, 2);
		secondconsonant = secondconsonant.toUpperCase();
		word = word.substring(2);
		word = secondconsonant + word + firstconsonant.toLowerCase() + ay;
	    } else {
		word = word.substring(1);
		word = word + firstconsonant.toLowerCase() + ay;
	    }

	}

	return word;
    }

}
