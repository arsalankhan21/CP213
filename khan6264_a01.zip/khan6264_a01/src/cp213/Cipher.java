package cp213;

/**
 * @author Arsalan Khan 210862640
 * @version 2023-01-24
 */
public class Cipher {
    // Constants
    public static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final int ALPHA_LENGTH = ALPHA.length();

    /**
     * Encipher a string using a shift cipher. Each letter is replaced by a letter
     * 'n' letters to the right of the original. Thus for example, all shift values
     * evenly divisible by 26 (the length of the English alphabet) replace a letter
     * with itself. Non-letters are left unchanged.
     *
     * @param s string to encipher
     * @param n the number of letters to shift
     * @return the enciphered string in all upper-case
     */
    public static String shift(final String s, final int n) {

	String encryptStr = "";

	for (int i = 0; i < s.length(); i++) {
	    int position = ALPHA.indexOf(s.charAt(i));
	    int cryptpos = (n + position) % 26;
	    char encryptChar = ALPHA.charAt(cryptpos);
	    encryptStr += encryptChar;

	}

	return encryptStr;
    }

    /**
     * Encipher a string using the letter positions in ciphertext. Each letter is
     * replaced by the letter in the same ordinal position in the ciphertext.
     * Non-letters are left unchanged. Ex:
     *
     * <pre>
    Alphabet:   ABCDEFGHIJKLMNOPQRSTUVWXYZ
    Ciphertext: AVIBROWNZCEFGHJKLMPQSTUXYD
     * </pre>
     *
     * A is replaced by A, B by V, C by I, D by B, E by R, and so on. Non-letters
     * are ignored.
     *
     * @param s          string to encipher
     * @param ciphertext ciphertext alphabet
     * @return the enciphered string in all upper-case
     */
    public static String substitute(final String s, final String ciphertext) {
	String encryptstr = "";

	for (int i = 0; i < s.length(); i++) {
	    if (Character.isLetter(s.charAt(i))) {
		char letter = s.charAt(i);
		for (int t = 0; t < ALPHA.length(); t++) {
		    char alpha = ALPHA.charAt(t);

		    if (letter == alpha) {
			encryptstr += ciphertext.charAt(t);
		    }
		}
	    }
	}

	return encryptstr;
    }

}
