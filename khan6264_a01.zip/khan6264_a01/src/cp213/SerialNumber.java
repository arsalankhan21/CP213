package cp213;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * @author Arsalan Khan 210862640
 * @version 2023-01-24
 */
public class SerialNumber {

    /**
     * Determines if a string contains all digits.
     *
     * @param str The string to test.
     * @return true if str is all digits, false otherwise.
     */
    public static boolean allDigits(final String str) {

	boolean digit = false;

	for (char ch : str.toCharArray()) {
	    if (!Character.isDigit(ch)) {
		return false;
	    }
	}

	return true;
    }

    /**
     * Determines if a string is a good serial number. Good serial numbers are of
     * the form 'SN/nnnn-nnn', where 'n' is a digit.
     *
     * @param sn The serial number to test.
     * @return true if the serial number is valid in form, false otherwise.
     */
    public static boolean validSn(final String sn) {
	boolean value = true;
	char tempvalue;

	if (sn.length() != 11) {
	    value = false;
	} else {
	    for (int i = 0; i < sn.length(); i++) {
		tempvalue = sn.charAt(i);
		if (i == 0) {
		    if (tempvalue != 'S') {
			value = false;
		    }
		} else if (i == 1) {
		    if (tempvalue != 'N') {
			value = false;
		    }
		} else if (i == 2) {
		    if (tempvalue != '/') {
			value = false;
		    }
		} else if ((i == 3) && (i == 4) && (i == 5) && (i == 6)) {
		    if (!Character.isDigit(tempvalue)) {
			value = false;
		    }
		} else if (i == 7) {
		    if (tempvalue != '-') {
			value = false;
		    }
		} else if ((i == 8) && (i == 9) && (i == 10)) {
		    if (!Character.isDigit(tempvalue)) {
			value = false;
		    }
		}

	    }
	}

	return value;
    }

    /**
     * Evaluates serial numbers from a file. Writes valid serial numbers to
     * good_sns, and invalid serial numbers to bad_sns.
     *
     * @param fileIn  a file already open for reading
     * @param goodSns a file already open for writing
     * @param badSns  a file already open for writing
     */
    public static void validSnFile(final Scanner fileIn, final PrintStream goodSns, final PrintStream badSns) {

	while (fileIn.hasNext()) {
	    String input = fileIn.next();
	    if (validSn(input)) {
		goodSns.println(input);
	    } else {
		badSns.println(input);
	    }
	}
	return;
    }

}
