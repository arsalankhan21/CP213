package cp213;

import java.time.LocalDate;

/**
 * Tests the Student class.
 *
 * @author Arsalan Khan
 * @version 2023-02-03
 */
public class Main {

    public static void main(String[] args) {
	final String line = "-".repeat(40);
	int id = 123456;
	String surname = "Brown";
	String forename = "David";
	LocalDate birthDate = LocalDate.parse("1962-10-25");
	Student student = new Student(id, surname, forename, birthDate);
	System.out.println("New Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test Getters");
	System.out.println(line);

	System.out.println("ID: " + student.getId());
	System.out.println("Surname: " + student.getSurname());
	System.out.println("Forename: " + student.getForename());
	System.out.println("Birthdate: " + student.getBirthDate());
	System.out.println();

	System.out.println(line);
	System.out.println("Test Setters");

	student.setId(654321);
	student.setSurname("Smith");
	student.setForename("John");
	student.setBirthDate(LocalDate.of(1980, 05, 15));

	System.out.println(line);
	System.out.println("Test Updated Getters");
	System.out.println(line);

	System.out.println("ID: " + student.getId());
	System.out.println("Surname: " + student.getSurname());
	System.out.println("Forename: " + student.getForename());
	System.out.println("Birthdate: " + student.getBirthDate());
	System.out.println();

	System.out.println(line);
	System.out.println("Test toString");
	System.out.println(line);
	System.out.println("Updated Student:");
	System.out.println(student);
	System.out.println(line);
	System.out.println("Test compareTo");

	Student student1 = new Student(123456, "Brown", "David", LocalDate.of(1962, 10, 25));
	Student student2 = new Student(654321, "Smith", "John", LocalDate.of(1980, 05, 15));

	System.out.println("Comparison result: " + student1.compareTo(student2));
    }

}
